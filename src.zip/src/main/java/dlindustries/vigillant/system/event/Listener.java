package dlindustries.vigillant.system.event;

public interface Listener {
}

