package dlindustries.vigillant.system.event;

public interface Event {
	default boolean isCancelled() {
		return false;
	}
}